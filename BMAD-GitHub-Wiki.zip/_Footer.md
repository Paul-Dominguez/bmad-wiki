[Home](Home) · [Master](Master-Template) · [Developer workflow](Developer-Workflow) · [References](References)

Draft · BMAD 6.12.0 · Human approval does not authorize the next phase.
